---
title: StyleTTS2 ukrainian demo
emoji: 🔈
colorFrom: indigo
colorTo: pink
sdk: gradio
sdk_version: 5.25.2
app_file: app.py
pinned: true
license: mit
short_description: StyleTTS2 trained on ukrainian dataset
---